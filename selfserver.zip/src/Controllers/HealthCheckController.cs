using SelfServer.src.Shared.Database;

namespace SelfServer.src.Controllers;

[ApiController]
[Route("api/[controller]")]
public class HealthCheckController : ControllerBase {
    private readonly IServiceProvider _serviceProvider;

    public HealthCheckController(IServiceProvider serviceProvider) {
        _serviceProvider = serviceProvider;
    }

    [HttpGet]
    public async Task<IActionResult> HealthCheck() {
        //testa conexão com o banco de dados
        var statusBancoAgro = false;
        try {
            var conn = _serviceProvider.GetRequiredService<IFirebirdConnectionFactory>();
            var sql = "select 1 from rdb$database";
            await conn.QueryFirstOrDefaultAsync<int>(sql);
            statusBancoAgro = true;
        } catch (Exception ex) {
            Log.Error(ex, "Erro ao testar conexão com o banco de dados");
        }

        //testa conexão com o banco de dados do self
        var statusBancoSelf = false;
        try {
            var conn = _serviceProvider.GetRequiredService<IFirebirdSelfConnectionFactory>();
            var sql = "select 1 from rdb$database";
            await conn.QueryFirstOrDefaultAsync<int>(sql);
            statusBancoSelf = true;
        } catch (Exception ex) {
            Log.Error(ex, "Erro ao testar conexão com o banco de dados do self");
        }

        //testa conexão com a api
        var statusApi = false;
        try {
            using var apiControlSoftRestService = _serviceProvider.GetRequiredService<IApiControlSoftRestService>();
            var response = await apiControlSoftRestService.GetAsync<dynamic>("/healthcheck");
            statusApi = response.TryGetProperty("status", out JsonElement statusElement) &&
                        statusElement.GetString() == "ok";
        } catch (Exception ex) {
            Log.Error(ex, "Erro ao testar conexão com a API");
        }

        return Ok(new { statusBancoAgro, statusBancoSelf, statusApi });
    }
}
