namespace CS_Server.Enumerados;

public enum ESysBackupSyncStatus {
    Pendente = 1,
    Erro = 5,
    Transferido = 9
}
