using SelfServer.src.Models.DTOs;
using SelfServer.src.Shared.Database;

namespace SelfServer.src.Repositories;

public interface ISyncSelfRepository {
    Task<IEnumerable<SyncSelfDataDto>> GetDadosClientesSelfAsync();
}

public class SyncSelfRepository : ISyncSelfRepository {
    private readonly IFirebirdSelfConnectionFactory _connectionFactory;
    private readonly IConfiguracaoDB _configuracao;

    public SyncSelfRepository(IFirebirdSelfConnectionFactory connectionFactory, IConfiguracaoDB configuracao) {
        _connectionFactory = connectionFactory;
        _configuracao = configuracao;
    }

    public async Task<IEnumerable<SyncSelfDataDto>> GetDadosClientesSelfAsync() {
        var baseAgroPath = _configuracao.Database;
        var sql = @$"SELECT
                        TB_HASH.GUUID HASH,
                        TB_HASH.NOME NOMEBASESELF,
                        CLIENTES_SELF.RAZAOSOCIAL CONSULTORSELF,
                        CASE TB_HASH.STATUS WHEN 'A' THEN 1 ELSE 0 END ATIVO
                    FROM TB_HASH
                        JOIN SP_CLIENTES_SELF('{baseAgroPath}') CLIENTES_SELF
                            ON CLIENTES_SELF.CODIGOCLIENTE = TB_HASH.CODIGOCONSULTOR";
        var data = await _connectionFactory.QueryAsync<SyncSelfDataDto>(sql);
        return data;
    }
}
