using CS_Server.Enumerados;
using SelfServer.src.Models.DTOs;
using SelfServer.src.Shared.Database;

namespace SelfServer.src.Repositories;

public interface ISysBackupRepository {
    Task<IEnumerable<SysbackupParaSyncDto>> ObterSysBackupParaSyncAsync();
    Task AtualizarStatusApiAsync(int id, ESysBackupSyncStatus statusApi, int idApi = 0);
}

public class SysBackupRepository : ISysBackupRepository {
    private readonly IFirebirdSelfConnectionFactory _conn;
    public SysBackupRepository(IFirebirdSelfConnectionFactory conn) {
        _conn = conn;
    }

    public Task<IEnumerable<SysbackupParaSyncDto>> ObterSysBackupParaSyncAsync() {
        var sql = @"
            SELECT TB_CLIENTESSYSAFRASYSBACKUP.ID,
                TB_CLIENTESSYSAFRASYSBACKUP.IDAPI,
                TB_HASH.IDSERVIDOR,
                TB_HASH.NOME,
                CASE
                    WHEN TB_HASH.TIPOBASE ='P' THEN
                        'Produção'
                    WHEN TB_HASH.TIPOBASE ='H' THEN
                        'Homologação'
                END AS VTIPOBASE,
                TB_CLIENTESSYSAFRASYSBACKUP.GUUID,
                TB_CLIENTESSYSAFRASYSBACKUP.HORARIOINICIAL,
                TB_CLIENTESSYSAFRASYSBACKUP.HORARIOFINAL,
                TB_CLIENTESSYSAFRASYSBACKUP.INTERVALO,
                TB_CLIENTESSYSAFRASYSBACKUP.STATUSAPI,
                (SELECT COUNT(TB_CLIENTES_HASH.ID) FROM TB_CLIENTES_HASH WHERE TB_CLIENTES_HASH.GUUID = TB_HASH.GUUID) AS QTDCLIENTE,
                TB_STATUSAPI.DESCRICAO AS DESCRICAO_STATUSAPI,
                TB_SOFTHOUSE.DESCRICAO AS DESCRICAO_SOFTHOUSE,
                TB_CLIENTESSYSAFRA.ATIVO AS CLIENTESSYSAFRAATIVO,
                TB_HASH.STATUS STATUSHASH,
                TB_CLIENTESSYSAFRA.GERACOBRANCA
            FROM TB_CLIENTESSYSAFRASYSBACKUP
            INNER JOIN TB_CLIENTESSYSAFRA ON TB_CLIENTESSYSAFRA.CODIGOSYSBACKUP = TB_CLIENTESSYSAFRASYSBACKUP.ID
            INNER JOIN TB_HASH            ON TB_HASH.GUUID   = TB_CLIENTESSYSAFRASYSBACKUP.GUUID
            INNER JOIN TB_SOFTHOUSE       ON TB_SOFTHOUSE.ID = TB_HASH.SOFTHOUSE
            INNER JOIN TB_STATUSAPI       ON TB_STATUSAPI.ID = TB_CLIENTESSYSAFRASYSBACKUP.STATUSAPI
            WHERE TRUE
            AND TB_CLIENTESSYSAFRASYSBACKUP.STATUSAPI NOT IN (9) --ENVIADO
        ";

        return _conn.QueryAsync<SysbackupParaSyncDto>(sql);
    }

    public Task AtualizarStatusApiAsync(int id, ESysBackupSyncStatus statusApi, int idApi = 0) {
        var sql = @$"
            UPDATE TB_CLIENTESSYSAFRASYSBACKUP
            SET STATUSAPI = @statusApi {(idApi > 0 ? ", IDAPI = @idApi" : "")}
            WHERE ID = @id
        ";

        return _conn.ExecuteAsync(sql, new { id, idApi, statusApi = (int)statusApi });
    }
}
