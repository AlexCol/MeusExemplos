using CSSharedLibrary.Connections;
using CSSharedLibrary.Services;

namespace SelfServer.src.Shared.Database;

public class FirebirdSelfConnectionFactory : FirebirdConnectionFactoryBase, IFirebirdSelfConnectionFactory {
    public FirebirdSelfConnectionFactory(ConfiguracaoDBSelf configuracao, IUsuarioLogado usuarioLogado)
        : base(FirebirdConnectionString.Get(configuracao), usuarioLogado) {
    }

    protected override async Task AutenticaLogAcessoAsync() {
        Log.Verbose("[Firebird Self Connection Factory] TB_Catalogo não aplicável ao SelfServer");
    }
}
