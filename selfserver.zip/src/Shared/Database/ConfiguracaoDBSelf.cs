using CSSharedLibrary.Configurations;

namespace SelfServer.src.Shared.Database;

public sealed class ConfiguracaoDBSelf : IConfiguracaoDB {
    private const int DefaultConnectionLifeTime = 15;
    private const int DefaultMinPoolSize = 0;
    private const int DefaultMaxPoolSize = 200;

    private readonly IConfiguration _configuration;

    public string Host { get; set; } = string.Empty;
    public int Port { get; set; }
    public string Database { get; set; } = string.Empty;
    public string User { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string Charset { get; set; } = string.Empty;
    public bool Pooling { get; set; }
    public int MinPoolSize { get; set; } = DefaultMinPoolSize;
    public int MaxPoolSize { get; set; } = DefaultMaxPoolSize;
    public int ConnectionLifeTime { get; set; } = DefaultConnectionLifeTime;

    public ConfiguracaoDBSelf(IConfiguration configuration) {
        _configuration = configuration;
        Reload();
    }

    public void Reload() {
        const string section = "DBSelf";

        Host = _configuration.GetValue($"{section}:Host", string.Empty) ?? string.Empty;
        Port = _configuration.GetValue($"{section}:Port", 3050);
        Database = _configuration.GetValue($"{section}:Database", string.Empty) ?? string.Empty;
        User = _configuration.GetValue($"{section}:User", string.Empty) ?? string.Empty;
        Password = _configuration.GetValue($"{section}:Password", string.Empty) ?? string.Empty;
        Charset = _configuration.GetValue($"{section}:Charset", string.Empty) ?? string.Empty;
        Pooling = _configuration.GetValue($"{section}:Pooling", false);
        MinPoolSize = _configuration.GetValue($"{section}:MinPoolSize", DefaultMinPoolSize);
        MaxPoolSize = _configuration.GetValue($"{section}:MaxPoolSize", DefaultMaxPoolSize);
        ConnectionLifeTime = _configuration.GetValue($"{section}:ConnectionLifeTime", DefaultConnectionLifeTime);
    }
}
