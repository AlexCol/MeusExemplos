using CSSharedLibrary.Connections;

namespace SelfServer.src.Shared.Database;

public interface IFirebirdSelfConnectionFactory : IFirebirdConnectionFactory {
}
