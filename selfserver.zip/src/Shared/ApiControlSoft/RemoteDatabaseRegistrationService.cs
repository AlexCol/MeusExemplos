namespace SelfServer.src.Shared.ApiControlSoft;

public sealed class RemoteDatabaseRegistrationService : CancelableServiceBase, IRemoteDatabaseRegistrationService {
    public Task ExecuteRegistrationCheckAsync(CancellationToken cancellationToken) {
        cancellationToken.ThrowIfCancellationRequested();
        Log.Verbose("[Remote Database Registration] Verificação de sincronização não aplicável ao SelfServer");
        return Task.CompletedTask;
    }

    public Task ExecuteVersionCheckAsync(CancellationToken cancellationToken) {
        cancellationToken.ThrowIfCancellationRequested();
        Log.Verbose("[Remote Database Registration] Envio de status do Server não aplicável ao SelfServer");
        return Task.CompletedTask;
    }
}
