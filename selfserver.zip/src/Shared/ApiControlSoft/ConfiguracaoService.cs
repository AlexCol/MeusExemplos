namespace SelfServer.src.Shared.ApiControlSoft;

public sealed class ConfiguracaoService : ServiceBase, IConfiguracaoService {
    private readonly IConfiguracaoDB _configuracaoDB;
    private readonly IConfiguracaoAPI _configuracaoAPI;
    private readonly IServiceScopeFactory _scopeFactory;
    private readonly IServiceProvider _serviceProvider;

    public string VersaoBase { get; private set; } = string.Empty;
    public string HashBase { get; private set; } = string.Empty;
    public string Fantasia { get; private set; } = string.Empty;
    public string RazaoSocial { get; private set; } = string.Empty;
    public List<IEmpresaAcessoModulo> EmpresaAcessoModuloList { get; } = [];
    public int ServerHttpPort { get; private set; }
    public bool IsVersaoBaseCliente { get; set; } = true;

    public ConfiguracaoService(
        IConfiguracaoDB configuracaoDB,
        IConfiguracaoAPI configuracaoAPI,
        IServiceScopeFactory scopeFactory,
        IServiceProvider serviceProvider) {
        _configuracaoDB = configuracaoDB;
        _configuracaoAPI = configuracaoAPI;
        _scopeFactory = scopeFactory;
        _serviceProvider = serviceProvider;
        ConfigureApiEnvironment();
    }

    public void CheckIsNullOrEmpty() {
        ConfigureApiEnvironment();
        if (HashBase.IsNullOrEmpty() || Fantasia.IsNullOrEmpty() ||
            VersaoBase.IsNullOrEmpty() || EmpresaAcessoModuloList.Count == 0)
            RefreshAll();
    }

    public void CheckModified() {
        var oldDatabase = _configuracaoDB.Database;
        _configuracaoDB.Reload();
        if (_configuracaoDB.Database.Equals(oldDatabase, StringComparison.OrdinalIgnoreCase))
            return;

        Log.Information("Configuração de banco alterada. Recarregando dados da API ControlSoft");
        RefreshAll();
        _serviceProvider.GetRequiredService<IApiControlSoftAuthorization>().Clear();
    }

    public async Task RefreshHashBase() {
        using var scope = _scopeFactory.CreateScope();
        using var connection = scope.ServiceProvider.GetRequiredService<IFirebirdConnectionFactory>();
        HashBase = await connection.QueryFirstOrDefaultAsync<string>("SELECT FIRST 1 GUUID FROM TB_CONFIG") ?? string.Empty;
        _configuracaoAPI.CsApiHash = HashBase;

        var sincronizaApi = await connection.QueryFirstOrDefaultAsync<string>("SELECT FIRST 1 SINCRONIZARAPI FROM TB_CONFIG");
        _configuracaoAPI.CsApiSincroniza = sincronizaApi?.Equals("S", StringComparison.OrdinalIgnoreCase) == true;
        Fantasia = await connection.QueryFirstOrDefaultAsync<string>("SELECT FIRST 1 FANTASIAEMPRESA FROM TB_EMPRESA ORDER BY TB_EMPRESA.CODIGOEMPRESA") ?? string.Empty;
        RazaoSocial = await connection.QueryFirstOrDefaultAsync<string>("SELECT FIRST 1 RAZAOSOCIALEMPRESA FROM TB_EMPRESA ORDER BY TB_EMPRESA.CODIGOEMPRESA") ?? string.Empty;

        await ChangeDatabaseHashToHomologationAsync(connection);
    }

    public async Task RefreshVersaoBase() {
        using var scope = _scopeFactory.CreateScope();
        using var connection = scope.ServiceProvider.GetRequiredService<IFirebirdConnectionFactory>();
        var encoded = await connection.QueryFirstOrDefaultAsync<string>("SELECT FIRST 1 VERSAO FROM TB_VERSAOEXE");
        VersaoBase = Encoding.UTF8.GetString(Convert.FromBase64String(encoded));
        IsVersaoBaseCliente = !VersaoBase.EndsWith("0", StringComparison.Ordinal);
    }

    public async Task RefreshEmpresaAcessoModulo() {
        using var scope = _scopeFactory.CreateScope();
        using var connection = scope.ServiceProvider.GetRequiredService<IFirebirdConnectionFactory>();
        var empresas = await connection.QueryAsync<EmpresaAcessoModulo>("SELECT * FROM TB_EMPRESAACESSOMODULO");
        EmpresaAcessoModuloList.Clear();
        EmpresaAcessoModuloList.AddRange(empresas);
    }

    private void ConfigureApiEnvironment() {
        _configuracaoAPI.ConfigVariaveisGlobais(SerialHDHelper.IsHDCadastrado);
    }

    private void RefreshAll() {
        RefreshHashBase().GetAwaiter().GetResult();
        RefreshVersaoBase().GetAwaiter().GetResult();
        RefreshEmpresaAcessoModulo().GetAwaiter().GetResult();
        ServerHttpPort = HttpHelper.GetHttpPortFromAddressesFeature(_serviceProvider);
        if (ServerHttpPort == 0)
            ServerHttpPort = HttpHelper.GetHttpPortFromAppSetings();

        Log.Information($"[Configuração API] Fantasia: {Fantasia}");
        Log.Information($"[Configuração API] Versão Base: {VersaoBase}");
        Log.Information($"[Configuração API] Hash: {HashBase}");
        Log.Information($"[Configuração API] Porta Http: {ServerHttpPort}");
    }

    private async Task ChangeDatabaseHashToHomologationAsync(IFirebirdConnectionFactory connection) {
        if (!SerialHDHelper.IsHDCadastrado || HashBase.StartsWith("HML", StringComparison.OrdinalIgnoreCase))
            return;

        var newHash = $"HML{SerialHDHelper.GetSerialHD()}{DateTime.Now:yyyyMMddHHmm}{HashBase}";
        if (newHash.Length > 100)
            newHash = newHash[..100];

        await connection.ExecuteAsync("UPDATE TB_CONFIG SET GUUID = @Hash", new { Hash = newHash });
        await connection.ExecuteAsync("UPDATE TB_EMPRESA SET GUUID = @Hash", new { Hash = newHash });
        _configuracaoAPI.CsApiHash = newHash;
        HashBase = newHash;
    }
}
