namespace SelfServer.src.Shared.ApiControlSoft;

[Table("TB_EMPRESAACESSOMODULO")]
public sealed class EmpresaAcessoModulo : EntityBase, IEmpresaAcessoModulo {
    [Key]
    public int CodigoEmpresa { get; set; }
    public char? UtilizaCsRomaneio { get; set; }
    public char? UtilizaCsComercializacao { get; set; }
    public char? UtilizaCsEmissor { get; set; }
    public char? UtilizaCsFinanceiro { get; set; }
    public char? UtilizaCsFaturamento { get; set; }
    public char? UtilizaCsTributacao { get; set; }
    public char? UtilizaCsLalur { get; set; }
    public char? UtilizaCsLcdpr { get; set; }
    public char? UtilizaCsEscritaFiscal { get; set; }
    public char? UtilizaCsContabilidade { get; set; }
}
