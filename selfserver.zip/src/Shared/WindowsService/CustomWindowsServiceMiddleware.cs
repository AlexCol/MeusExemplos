using CSSharedLibrary.Middlewares;

namespace SelfServer.src.Shared.WindowsService;

public sealed class CustomWindowsServiceMiddleware : ObjectBase, ICustomWindowsServiceMiddleware {
    public void ExecuteOnApplicationStopping() {
        Log.Verbose("[SelfServer] Iniciando parada da aplicação");
    }

    public void ExecuteOnApplicationStopped() {
        Log.Verbose("[SelfServer] Aplicação finalizada");
    }

    public Task ExecuteStartAsync(CancellationToken cancellationToken) {
        cancellationToken.ThrowIfCancellationRequested();
        Log.Verbose("[SelfServer] Ciclo de vida do serviço iniciado");
        return Task.CompletedTask;
    }

    public Task ExecuteStopAsync(CancellationToken cancellationToken) {
        Log.Verbose("[SelfServer] Ciclo de vida do serviço finalizado");
        return Task.CompletedTask;
    }
}
