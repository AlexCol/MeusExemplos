using CS_Server.Enumerados;
using SelfServer.src.Models.DTOs;
using SelfServer.src.Repositories;

namespace SelfServer.src.Services;

public interface ISyncSelfService {
    Task EnviarSelfDataParaSyncAsync();
}

public class SyncSelfService : ISyncSelfService {
    private readonly IApiControlSoftRestService _apiControlSoftRestService;
    private readonly ISyncSelfRepository _syncSelfRepository;

    public SyncSelfService(IApiControlSoftRestService apiControlSoftRestService, ISyncSelfRepository syncSelfRepository) {
        _apiControlSoftRestService = apiControlSoftRestService;
        _syncSelfRepository = syncSelfRepository;
    }

    public async Task EnviarSelfDataParaSyncAsync() {
        var clientesSelf = await _syncSelfRepository.GetDadosClientesSelfAsync();

        var ajustados = 0;
        foreach (var cliente in clientesSelf) {
            try {
                await _apiControlSoftRestService.PatchAsync<dynamic>("/v1/cliente/sync-self", cliente);
                ajustados++;
            } catch (Exception ex) {
                Log.Error($"Erro ao enviar dados para sync: {ex.Message}");
            }
        }
        Log.Information($"[SyncSelfService] Envio de dados para sync concluído. Total de registros enviados: {ajustados}");

    }

    private async Task<IEnumerable<string>> GetDadosSemSyncAsync() {
        var resposne = await _apiControlSoftRestService.GetAsync<IEnumerable<string>>("/v1/cliente/sem-dados-self");
        return resposne;
    }
}
