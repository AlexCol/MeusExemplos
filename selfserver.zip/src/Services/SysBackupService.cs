using CS_Server.Enumerados;
using SelfServer.src.Models.DTOs;
using SelfServer.src.Repositories;

namespace SelfServer.src.Services;

public interface ISysBackupService {
    Task EnviarSysBackupParaSyncAsync();
}

public class SysBackupService : ISysBackupService {
    private readonly ISysBackupRepository _sysBackupRepository;
    private readonly IApiControlSoftRestService _apiControlSoftRestService;

    public SysBackupService(ISysBackupRepository sysBackupRepository, IApiControlSoftRestService apiControlSoftRestService) {
        _sysBackupRepository = sysBackupRepository;
        _apiControlSoftRestService = apiControlSoftRestService;
    }

    public async Task EnviarSysBackupParaSyncAsync() {
        var dadosParaSync = await _sysBackupRepository.ObterSysBackupParaSyncAsync();
        var dadosParaSyncList = dadosParaSync.ToList();
        var totalDados = dadosParaSyncList.Count;

        if (totalDados == 0) {
            Log.Information("[SYSBACKUP] Nenhum dado para enviar para sync.");
            return;
        }

        var enviados = 0;
        foreach (var dado in dadosParaSyncList) {
            try {
                var json = new {
                    ativo = dado.ClientesSysafraAtivo,
                    horarioinicial = dado.HorarioInicial.ToString(@"hh\:mm\:ss"),
                    horariofinal = dado.HorarioFinal.ToString(@"hh\:mm\:ss"),
                    intervalo = dado.Intervalo,
                    hash = dado.Guuid,
                    serialhd = dado.IdServidor,
                    geracobranca = dado.GeraCobranca
                };

                var response = await _apiControlSoftRestService.PostAsync<SysBackupSyncResponseDto>("/sysafra/v1/sysbackup/clientes", json);
                await _sysBackupRepository.AtualizarStatusApiAsync(dado.Id, ESysBackupSyncStatus.Transferido, response.Id);
                enviados++;
            } catch (Exception ex) {
                Log.Error(ex, $"[SYSBACKUP] Erro ao enviar sysbackup para sync. ID: {dado.Id}, Hash: {dado.Guuid}");
                await _sysBackupRepository.AtualizarStatusApiAsync(dado.Id, ESysBackupSyncStatus.Erro);
            }

            Log.Information($"[SYSBACKUP] Enviados {enviados} de {totalDados} dados para sync.");
        }
    }
}
