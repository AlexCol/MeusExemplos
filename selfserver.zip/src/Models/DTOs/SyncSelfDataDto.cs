namespace SelfServer.src.Models.DTOs;

public class SyncSelfDataDto {
    public string Hash { get; set; } = string.Empty;
    public string ConsultorSelf { get; set; } = string.Empty;
    public string NomeBaseSelf { get; set; } = string.Empty;
    public int Ativo { get; set; }
}
