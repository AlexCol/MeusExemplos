namespace SelfServer.src.Models.DTOs;

public class SysBackupSyncResponseDto {
    public int Id { get; set; }
}
