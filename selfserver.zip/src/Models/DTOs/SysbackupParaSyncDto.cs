namespace SelfServer.src.Models.DTOs;

public class SysbackupParaSyncDto {
    public int Id { get; set; }
    public int IdApi { get; set; }
    public string IdServidor { get; set; } = string.Empty;
    public string Nome { get; set; } = string.Empty;
    public string VTipoBase { get; set; } = string.Empty;
    public string Guuid { get; set; } = string.Empty;
    public TimeSpan HorarioInicial { get; set; }
    public TimeSpan HorarioFinal { get; set; }
    public short Intervalo { get; set; }
    public short StatusApi { get; set; }
    public long QtdCliente { get; set; }
    public string DescricaoStatusApi { get; set; } = string.Empty;
    public string DescricaoSoftHouse { get; set; } = string.Empty;
    public bool ClientesSysafraAtivo { get; set; }
    public string StatusHash { get; set; } = string.Empty;
    public bool GeraCobranca { get; set; }
}
