using Quartz;

namespace SelfServer.src.Jobs;

public static class QuartzMiddleware {
    public static void AddQuartzMiddleware(this IServiceCollection services) {
        services.AddQuartz(quartz => {
            quartz.SchedulerId = "Scheduler-SelfServer";

            quartz.UseSimpleTypeLoader();
            quartz.UseInMemoryStore();
            quartz.UseDefaultThreadPool(tp => {
                tp.MaxConcurrency = 10;
            });

            SyncSysBackupJob.BuildQuartzJob(quartz);
            SyncSelfDataJob.BuildQuartzJob(quartz);
        });

        services.AddQuartzHostedService(options => {
            options.WaitForJobsToComplete = true;
        });
    }
}
