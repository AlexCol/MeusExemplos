using Quartz;
using SelfServer.src.Services;

namespace SelfServer.src.Jobs;

public class SyncSelfDataJob(IServiceProvider serviceProvider) : ICSJob {
    private readonly IServiceProvider _serviceProvider = serviceProvider;

    public async Task Execute(IJobExecutionContext context) {
        var syncService = _serviceProvider.GetRequiredService<ISyncSelfService>();
        await syncService.EnviarSelfDataParaSyncAsync();
    }

    public static DetailsJob GetJobDetails() {
        var JobName = "SyncSelfDataJob";
        return new DetailsJob {
            Nome = JobName,
            Grupo = $"Grupo{JobName}",
            Trigger = $"Trigger{JobName}",
            Intervalo = 1 * 60 * 60, //de hora em hora
            Delay = 15, //15 segundos de delay para iniciar o job
            Funcionalidade = "SelfData",
            Objetivo = "Job de sincronização dos dados do Self. Ex. Nome do Consultor e Nome da Base."
        };
    }

    public static void BuildQuartzJob(IServiceCollectionQuartzConfigurator quartz) {
        var selfData = SyncSelfDataJob.GetJobDetails();
        var jobSelfDataKey = new JobKey(selfData.Nome, selfData.Grupo);
        quartz.AddJob<SyncSelfDataJob>(jobSelfData => jobSelfData.StoreDurably().WithIdentity(jobSelfDataKey).WithDescription("Descricao job SyncSelfData"));
        quartz.AddTrigger(triggerSelfData => triggerSelfData
            .WithIdentity(selfData.Trigger)
            .ForJob(jobSelfDataKey)
            .StartAt(DateBuilder.EvenSecondDate(DateTimeOffset.UtcNow.AddSeconds(selfData.Delay)))
            .WithDescription("Descricao trigger de SyncSelfData")
        );
    }
}
