using Quartz;
using SelfServer.src.Services;

namespace SelfServer.src.Jobs;

public class SyncSysBackupJob(IServiceProvider serviceProvider) : ICSJob {
    private readonly IServiceProvider _serviceProvider = serviceProvider;

    public async Task Execute(IJobExecutionContext context) {
        var sysBackupService = _serviceProvider.GetRequiredService<ISysBackupService>();
        await sysBackupService.EnviarSysBackupParaSyncAsync();
    }

    public static DetailsJob GetJobDetails() {
        var JobName = "SyncSysBackUpJob";
        return new DetailsJob {
            Nome = JobName,
            Grupo = $"Grupo{JobName}",
            Trigger = $"Trigger{JobName}",
            Intervalo = 1 * 60 * 60, //de hora em hora
            Delay = 15, //15 segundos de delay para iniciar o job
            Funcionalidade = "SysBackup",
            Objetivo = "Job de sincronização de backup do sistema."
        };
    }

    public static void BuildQuartzJob(IServiceCollectionQuartzConfigurator quartz) {
        var sysBackup = SyncSysBackupJob.GetJobDetails();
        var jobSysBackupKey = new JobKey(sysBackup.Nome, sysBackup.Grupo);
        quartz.AddJob<SyncSysBackupJob>(jobSysBackup => jobSysBackup.StoreDurably().WithIdentity(jobSysBackupKey).WithDescription("Descricao job SyncSysBackUp"));
        quartz.AddTrigger(triggerSysBackup => triggerSysBackup
            .WithIdentity(sysBackup.Trigger)
            .ForJob(jobSysBackupKey)
            .StartAt(DateBuilder.EvenSecondDate(DateTimeOffset.UtcNow.AddSeconds(sysBackup.Delay)))
            .WithDescription("Descricao trigger de SyncSysBackUp")
        );
    }
}
