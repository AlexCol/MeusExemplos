namespace SelfServer.src.Config.DependencyInjection;

using SelfServer.src.Shared.Database;
using SelfServer.src.Shared.ApiControlSoft;
using SelfServer.src.Shared.WindowsService;
using CSSharedLibrary.Middlewares;
using SelfServer.src.Services;
using SelfServer.src.Repositories;

public static partial class DependencyInjectionMiddleware {
    public static void AddDependencyInjectionMiddleware(this IServiceCollection services) {
        services.AddDependencyInjectionSistemaMiddleware();

        services.AddScoped<ISysBackupService, SysBackupService>();
        services.AddScoped<ISysBackupRepository, SysBackupRepository>();

        services.AddScoped<ISyncSelfService, SyncSelfService>();
        services.AddScoped<ISyncSelfRepository, SyncSelfRepository>();
    }

    private static void AddDependencyInjectionSistemaMiddleware(this IServiceCollection services) {
        services.AddSingleton<IConfiguracaoServer, ConfiguracaoServer>();
        services.AddSingleton<IConfiguracaoModulo, ConfiguracaoModulo>();

        services.AddSingleton<IConfiguracaoDB, ConfiguracaoDB>();
        services.AddTransient<IUsuarioLogado, UsuarioLogado>();

        services.AddScoped<IFirebirdConnectionFactory, FirebirdConnectionFactory>();
        services.AddSingleton<ConfiguracaoDBSelf>();
        services.AddScoped<IFirebirdSelfConnectionFactory, FirebirdSelfConnectionFactory>();

        services.AddSingleton<IConfiguracaoAPI, ConfiguracaoAPI>();
        services.AddSingleton<IConfiguracaoService, ConfiguracaoService>();
        services.AddSingleton<IApiControlSoftAuthorization, ApiControlSoftAuthorization>();
        services.AddTransient<IRemoteDatabaseRegistrationService, RemoteDatabaseRegistrationService>();
        services.AddTransient<ICustomWindowsServiceMiddleware, CustomWindowsServiceMiddleware>();
    }
}
