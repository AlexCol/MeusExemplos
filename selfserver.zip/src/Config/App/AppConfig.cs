using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CSSharedLibrary.Middlewares;
using Microsoft.Extensions.FileProviders;
using Microsoft.Extensions.Primitives;

namespace SelfServer.src.Config.App;

public static class AppConfig {
    public static void ConfigureApp(this WebApplication app) {
        ChangeToken.OnChange(() => app.Configuration.GetReloadToken(),
                     () => {
                         var configuracao = app.Services.GetRequiredService<IConfiguracaoService>();
                         configuracao.CheckModified();

                         Log.CloseAndFlush();
                         Log.Logger = new LoggerConfiguration().ReadFrom.Configuration(app.Configuration).CreateLogger();
                     });

        app.UseDefaultFiles();
        app.UseStaticFiles(new StaticFileOptions() { FileProvider = new PhysicalFileProvider(ApplicationUtil.RootPath) });

        app.UseRouting();
        app.UseCors(x => x.AllowAnyOrigin().AllowAnyMethod().AllowAnyHeader());

        app.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");
        app.UseStatusCodePages();

        app.UseAuthentication();
        app.UseAuthorization();

        app.UseResponseCompression();

        Log.Information($"Iniciando {ApplicationUtil.ApplicationDisplayName}");
        Log.Information($"Versao: {ApplicationUtil.Versao}");
        Log.Information($"ConfigFile: {ApplicationUtil.ConfigFile}");
        Log.Information($"BasePath: {ApplicationUtil.BasePath}");
        Log.Information($"wwwroot: {ApplicationUtil.RootPath}");

        ResourceHelper.ExtractEmbeddedResources(ApplicationUtil.RootPath, "Resources\\wwwroot\\", Assembly.GetExecutingAssembly());
    }
}
