global using System;
global using System.IO;
global using System.Diagnostics;
global using System.Reflection;
global using System.Collections;
global using System.Collections.Generic;
global using System.Linq;
//global using System.Net;
global using System.Data.Common;
global using System.Globalization;
global using System.Text;
global using System.Text.Json;
global using System.Threading.Tasks;
global using System.Text.Json.Serialization;
global using System.Data;
global using System.Dynamic;

global using Serilog;
//global using FirebirdSql.Data.FirebirdClient;
global using Dapper;
global using Dapper.Contrib.Extensions;
global using System.ComponentModel;
global using System.ComponentModel.DataAnnotations;
global using System.ComponentModel.DataAnnotations.Schema;

global using CSSharedLibrary.Base;
global using CSSharedLibrary.Models;
global using CSSharedLibrary.Util;
global using CSSharedLibrary.Enums;
global using CSSharedLibrary.Configurations;
global using CSSharedLibrary.Exceptions;
global using CSSharedLibrary.Extensions;
global using CSSharedLibrary.Repositories;
global using CSSharedLibrary.Services;
global using CSSharedLibrary.Connections;
global using CSSharedLibrary.Helpers;
global using CSSharedLibrary.TaskScheduling;
global using CSSharedLibrary.Entities;

global using Microsoft.AspNetCore.Authorization;
global using Microsoft.AspNetCore.Mvc;
global using Microsoft.Extensions.DependencyInjection;
global using Microsoft.Extensions.Hosting;
global using Microsoft.AspNetCore.Authentication.JwtBearer;
global using Microsoft.IdentityModel.Tokens;

global using Microsoft.AspNetCore.Builder;
global using Microsoft.AspNetCore.Hosting;
global using Microsoft.AspNetCore.Diagnostics;
global using Microsoft.AspNetCore.Http;

