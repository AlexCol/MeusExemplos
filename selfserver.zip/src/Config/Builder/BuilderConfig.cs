using CSSharedLibrary.Middlewares;
using SelfServer.src.Config.Builder.helpers;
using SelfServer.src.Config.DependencyInjection;
using SelfServer.src.Jobs;

namespace SelfServer.src.Config.Builder;

public static class BuilderConfig {
    public static void ConfigureBuilder(this WebApplicationBuilder builder) {
        builder.DefaultAppSettingsValidade();

        builder.Configuration.SetBasePath(ApplicationUtil.BasePath);
        builder.Configuration.AddJsonFile(ApplicationUtil.ConfigFile, optional: false, reloadOnChange: true);
        builder.Configuration.AddEnvironmentVariables(prefix: ApplicationUtil.InstancePrefix);

        Log.Logger = new Serilog.LoggerConfiguration().ReadFrom.Configuration(builder.Configuration).CreateLogger();
        builder.Host.UseSerilog();
        Log.Information("Iniciando Serilog");

        builder.WebHost.UseKestrel(options => { options.Configure(builder.Configuration.GetSection("Kestrel")); });

        if (ApplicationUtil.IsSingleFile) {
            builder.Host.UseWindowsService(options => { options.ServiceName = ApplicationUtil.ApplicationName; });
            builder.Services.AddHostedService<WindowsServiceMiddleware>();
        }

        builder.Services.AddControllersWithViews()
                .AddJsonOptions(options => {
                    options.JsonSerializerOptions.DictionaryKeyPolicy = new LowerCaseNamingPolicy();
                    options.JsonSerializerOptions.PropertyNamingPolicy = new LowerCaseNamingPolicy();
                    options.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
                });

        builder.Services.AddDependencyInjectionMiddleware();
        builder.Services.AddAuthenticationMiddleware();
        builder.Services.AddAuthorizationMiddleware();
        builder.Services.AddCompressionMiddleware();
        builder.Services.AddHttpContextAccessor();
        builder.Services.AddQuartzMiddleware();

        builder.Services.AddHttpClient<IApiControlSoftAuthorizationService, ApiControlSoftAuthorizationService>()
                .SetHandlerLifetime(TimeSpan.FromMinutes(10));

        builder.Services.AddHttpClient<IApiControlSoftRestService, ApiControlSoftRestService>()
                .SetHandlerLifetime(TimeSpan.FromMinutes(10));
    }
}
