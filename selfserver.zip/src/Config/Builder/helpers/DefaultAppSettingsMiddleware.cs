using System.Text.Json.Nodes;
using CSSharedLibrary.Middlewares;

namespace SelfServer.src.Config.Builder.helpers;

public static class DefaultAppSettingsMiddleware {
    public static void DefaultAppSettingsValidade(this WebApplicationBuilder _) {
        var updateConfig = false;
        var configurationText = File.ReadAllText(ApplicationUtil.ConfigFile);
        var configurationJson = JsonNode.Parse(configurationText);

        DefaultSerilogAppSettingsMiddleware.Validate(configurationJson!, ref updateConfig);

        if (updateConfig) {
            var updatedConfigurationJson = JsonSerializer.Serialize(configurationJson, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(ApplicationUtil.ConfigFile, updatedConfigurationJson);
        }
    }
}
