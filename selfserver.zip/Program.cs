using SelfServer.src.Config.App;
using SelfServer.src.Config.Builder;

CultureInfo.DefaultThreadCurrentCulture = new CultureInfo("pt-BR");
CultureInfo.DefaultThreadCurrentUICulture = new CultureInfo("pt-BR");

var webApplicationOptions = new WebApplicationOptions() {
    ApplicationName = typeof(Program).Assembly.FullName,
    ContentRootPath = ApplicationUtil.BasePath,
    WebRootPath = ApplicationUtil.RootPath,
    Args = args
};

var builder = WebApplication.CreateBuilder(webApplicationOptions);
builder.ConfigureBuilder();

var app = builder.Build();
app.ConfigureApp();

try {
    app.Run();
} catch (Exception ex) {
    Log.Fatal($"Erro ao iniciar: {ex.Message}");
    Environment.Exit(0);
} finally {
    Log.Information($"Finalizado {ApplicationUtil.ApplicationDisplayName}");
    Log.CloseAndFlush();
}
