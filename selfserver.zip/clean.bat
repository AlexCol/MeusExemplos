@echo off
setlocal

:: Obtém o diretório onde o script BAT está localizado
set "BASE_DIR=%~dp0"

echo Excluindo pastas "bin" e "obj" em "%BASE_DIR%" e suas subpastas...

for /d /r "%BASE_DIR%" %%d in (bin, obj, Properties) do (
    if exist "%%d" (
        echo Removendo %%d
        rmdir /s /q "%%d"
    )
)

echo Limpeza concluida!