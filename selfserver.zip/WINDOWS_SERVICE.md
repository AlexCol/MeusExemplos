# Serviço Windows — SelfServer

Execute os comandos abaixo em um **PowerShell aberto como Administrador**.

## Instalar

```powershell
New-Service `
  -Name "CS-SelfServer" `
  -DisplayName "ControlSoft SelfServer" `
  -BinaryPathName '"C:\ControlSoft Agro\SelfServer\SelfServer.exe"' `
  -StartupType Automatic
```

## Iniciar

```powershell
Start-Service -Name "CS-SelfServer"
```

## Consultar o estado

```powershell
Get-Service -Name "CS-SelfServer"
```

## Parar

```powershell
Stop-Service -Name "CS-SelfServer"
```

## Desinstalar

```powershell
Stop-Service -Name "CS-SelfServer" -ErrorAction SilentlyContinue
sc.exe delete "CS-SelfServer"
```

Após executar `sc.exe delete`, aguarde alguns segundos antes de instalar novamente o serviço.

## Consultar logs

Os logs da instalação padrão ficam em:

```text
C:\ControlSoft Agro\SelfServer\Log
```
