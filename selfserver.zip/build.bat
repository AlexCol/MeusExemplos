@echo off
:inicio
cls

set "FASTBUILD=0"
if /i "%1"=="skip" (
    set "FASTBUILD=1"
    goto fastbuild
)

set "choice=1"
echo =====================================
echo 1. SelfServer
echo 2. SySSelfServer
echo =====================================
set /P choice=Escolha uma opcao [1]:

:fastbuild
if "%choice%"=="" set choice=1

set VERSAO=2024.3.1.0
set PROJETO="SelfServer.csproj"
set SOLUCAO="SelfServer.sln"
set DIRETORIO_BUILD="bin\Release\net8.0\win-x64\publish\SelfServer.exe"
set /a randomNumber=%random% %% 100 + 1

if "%choice%"=="2" goto sys

:cs
color 2F
set DIRETORIO_SelfServer="C:\ControlSoft Agro\SelfServer\*"
set Company="ControlSoft Acessoria e Desenvolvimento"
set Copyright="ControlSoft 2024"
set AssemblyTitle="ControlSoft SelfServer%"
set Product="CS SelfServer Randon Build %randomNumber%"
set Description="ControlSoft SelfServer"
goto build

:sys
color b1
set DIRETORIO_SelfServer="C:\Sysafra Agro\SelfServer\*"
set Company="SySafra Acessoria e Desenvolvimento"
set Copyright="SySafra 2024"
set AssemblyTitle="SySafra SelfServer"
set Product="SyS SelfServer Randon Build %randomNumber%"
set Description="SySafra SelfServer"

:build
if "%FASTBUILD%"=="1" goto buildapplication

:buildsolution
echo Limpando e Restaurando Solucao %SOLUCAO%...
dotnet clean %SOLUCAO%
dotnet restore %SOLUCAO%
dotnet build %SOLUCAO%

:buildapplication
echo Limpando e Restaurando Aplicacao %PROJETO%...
dotnet clean %PROJETO%
dotnet restore %PROJETO%

echo Compilando Aplicacao %PROJETO%...
dotnet publish -f net8.0 -c Release -r win-x64 %PROJETO% /p:PublishSingleFile=true,FileVersion=%VERSAO%,InformationalVersion=%VERSAO%,AssemblyVersion=%VERSAO%,AssemblyTitle=%AssemblyTitle%,Company=%AssemblyCompany%,Copyright=%Copyright%,Product=%Product%,Description=%Description% /p:IncludeNativeLibrariesForSelfExtract=true

if "%choice%"=="1" (
  if exist "C:\Controlsoft Agro\SelfServer\SelfServer.exe" del "C:\Controlsoft Agro\SelfServer\SelfServer.exe"
)

if "%choice%"=="2" (
  if exist "C:\SySafra Agro\SelfServer\SySSelfServer.exe" del "C:\SySafra Agro\SelfServer\SySSelfServer.exe"
)

call xcopy %DIRETORIO_BUILD% %DIRETORIO_SelfServer% /y

if "%choice%"=="2" (
  ren "C:\SySafra Agro\SelfServer\SelfServer.exe" SySSelfServer.exe
)

echo =====================================
if ERRORLEVEL 1 (
    color 4F
    echo Erro ao Compilar %PROJETO%
    if /i "%1"=="skip" pause
) else (
    color F1
    cls
    echo Compilado %PROJETO%
)
echo =====================================

if "%FASTBUILD%"=="1" goto nextproject

pause

color 0F
goto inicio

:nextproject
echo Finalizando...
exit /b
